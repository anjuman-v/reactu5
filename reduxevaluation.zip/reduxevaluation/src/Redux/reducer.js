const init = {};

export const reducer = (store = init, { type, payload }) => {
  switch (type) {
    default:
      return store;
  }
};
